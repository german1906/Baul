package com.gh.controller;
import com.gh.model.User;
import com.gh.service.HibernateSearchService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class SearchController {

    @Autowired
    private HibernateSearchService searchservice;

    @RequestMapping("/search/{q}")
    public List<User> search(@PathVariable("q") String q, Model model) {
        List<User> searchResults = null;
        try {
            searchResults = searchservice.fuzzySearch(q);

        } catch (Exception ex) {
            // here you should handle unexpected errors
            // ...
            // throw ex;
        }
        //model.addAttribute("search", searchResults);
        return searchResults;

    }

}
