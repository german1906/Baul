package com.grokonez.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grokonez.api.service.HibernateSearchService;
import com.grokonez.api.service.IUserService;
import com.grokonez.jwtauthentication.model.User;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping
public class UserController {
	
	@Autowired
	public IUserService IUserService;
	
	@Autowired
	public  HibernateSearchService HibernateSearchService;
	
	
	@GetMapping("users/all")
	public List<User> buscarTodos(){
		 List<User> users = IUserService.buscarTodos();
		return users;
	}

	@RequestMapping("search/{q}")
    public List<User> search(@PathVariable("q") String q, User user) {
        List<User> searchResults = null;
        try {
            //cardservice.addCards();
            searchResults = HibernateSearchService.fuzzySearch(q);

        } catch (Exception ex) {
            // here you should handle unexpected errors
            // ...
            // throw ex;
        }
        return searchResults;

    }
}
