package com.grokonez.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.grokonez.api.repository.*;
import com.grokonez.jwtauthentication.model.User;
import com.grokonez.jwtauthentication.repository.UserRepository;

@Service
public class UserServiceImpl implements IUserService{
	
	@Autowired
	public UserRepository UserRepository;

	@Override
	public List<User> buscarTodos() {
		List<User> user = UserRepository.findAll();
		return user;
	}

}
