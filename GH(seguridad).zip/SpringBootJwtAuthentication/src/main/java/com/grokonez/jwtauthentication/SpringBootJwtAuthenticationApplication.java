package com.grokonez.jwtauthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;



//@SpringBootApplication(scanBasePackageClasses = {com.grokonez.api.controller.UserController.class,com.grokonez.api.repository.UserRepository.class,com.grokonez.api.service.IUserService.class})


/*@SpringBootApplication(exclude = {SecurityAutoConfiguration.class }, scanBasePackages = {"com.grokonez.jwtauthentication","com.grokonez.api"})
@EnableJpaRepositories ({"com.grokonez.api.repository","com.grokonez.jwtauthentication.repository"})*/
//@Import(value={com.grokonez.api.repository.UserRepository.class,com.grokonez.api.repository.UserRepository.class})
//@EnableJpaRepositories ({"com.grokonez.jwtauthentication.repository"})

// this fix the problem


@EnableAutoConfiguration
@SpringBootApplication(exclude = {SecurityAutoConfiguration.class }, scanBasePackages = {"com.grokonez.jwtauthentication","com.grokonez.api"})
public class SpringBootJwtAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJwtAuthenticationApplication.class, args);
	}
}


